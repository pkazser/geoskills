# Τεκμηρίωση δεδομένων GQ00

- Dataset: `world_countries.gpkg`, επίπεδα `countries` (177 εγγραφές) και `greece` (1 εγγραφή).
- Δεδομένα: ιστορικό, απλοποιημένο `naturalearth_lowres` μέσω διανομής pyogrio, καταγωγής Natural Earth.
- Άδεια πρωτογενούς Natural Earth: public domain. [Natural Earth](https://www.naturalearthdata.com/about/terms-of-use/)
- Χρήση: μικρό εισαγωγικό εκπαιδευτικό dataset, **όχι** επίσημα/επικαιροποιημένα σύνορα ή γεωδαιτική ακρίβεια.
- SHA256 αρχείου: `e597ae8e68718a5b29e9b1045c36ba23cf668ce29c5db67ac9a692a99716e58c`
- Η έκδοση v1.1 του μαθησιακού πακέτου παραμένει σταθερή για αναπαραγωγιμότητα.
