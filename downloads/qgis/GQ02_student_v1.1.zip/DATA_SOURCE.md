# Προέλευση δεδομένων

Το `data/geoskills_learning_area_v0.1.gpkg` είναι αντίγραφο του συνθετικού εκπαιδευτικού GeoPackage του GQ01. Το `reference/gq02_services_wgs84_reference_v0.1.gpkg` είναι παράγωγο μόνο του επιπέδου `services`: οι γεωμετρίες μετασχηματίστηκαν από EPSG:2100 σε EPSG:4326 με pyproj/PROJ και τα γνωρίσματα διατηρήθηκαν.

Το reference layer χρησιμοποιείται αποκλειστικά για έλεγχο του δικού σου αποτελέσματος. Δεν αντικαθιστά την άσκηση Reproject layer.

Πηγή μαθήματος: https://pkazser.github.io/geoskills/courses/qgis/gq02/

Προτεινόμενη αναφορά: GeoSkills — Συνθετικό εκπαιδευτικό σύνολο γεωχωρικών δεδομένων GQ01 v0.1, παράγωγο αναφοράς GQ02 με μετασχηματισμό EPSG:2100 → EPSG:4326.
