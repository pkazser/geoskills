# Παραδοτέα

Αποθήκευσε εδώ το `GQ05_digitized.gpkg` με τα τρία δικά σου layers.
