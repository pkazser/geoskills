GEOSKILLS — GQ00 — ΠΑΚΕΤΟ ΦΟΙΤΗΤΗ v2.1

1. Αποσυμπίεσε ολόκληρο το αρχείο σε έναν μόνιμο φάκελο. Μην εργάζεσαι μέσα από το ZIP.
2. Κράτησε μαζί τους φακέλους data/, projects/ και exercises/.
3. Άνοιξε το QGIS 3.44 LTR και φόρτωσε το data/world_countries.gpkg.
4. Στο τέλος αποθήκευσε το έργο σου ως projects/GQ00_my_first_map.qgz.
5. Συμπλήρωσε το Word `exercises/GQ00_Fyllo_Ergasias_v2.1.docx` ή, εναλλακτικά, το Markdown `exercises/GQ00_fyllo_ergasias.md`.

Το επίπεδο countries έχει 177 εγγραφές και το επίπεδο greece μία εγγραφή.
Το GeoPackage είναι εκπαιδευτικό, ιστορικό και απλοποιημένο υποσύνολο Natural Earth.
Δεν περιλαμβάνεται έτοιμο αρχείο .qgz: δημιούργησε το δικό σου έργο.

## Φύλλο εργασίας και παραδοτέα

Το Word είναι η προτεινόμενη επεξεργάσιμη μορφή του φύλλου εργασίας: `exercises/GQ00_Fyllo_Ergasias_v2.1.docx`. Το Markdown παραμένει διαθέσιμο ως εναλλακτική μορφή: `exercises/GQ00_fyllo_ergasias.md`. Δεν περιλαμβάνονται λύσεις ή συμπληρωμένα παραδείγματα.
