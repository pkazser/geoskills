# Projects

Αποθήκευσε εδώ το `GQ04_my_observations.qgz` αφού δημιουργήσεις και ελέγξεις το GeoPackage. Δεν παρέχεται έτοιμο QGZ.
