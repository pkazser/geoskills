# Outputs

Αποθήκευσε εδώ το `GQ04_observations.gpkg` που θα δημιουργήσεις με το Layer → Export → Save Features As… Δεν παρέχεται έτοιμο GeoPackage.
