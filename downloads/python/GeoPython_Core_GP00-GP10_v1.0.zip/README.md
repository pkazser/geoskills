# GeoPython Core GP00–GP10 — συγκεντρωτικό πακέτο v1.0

Το πακέτο περιέχει μόνο τα starter notebooks των GP00–GP10 και τα εκπαιδευτικά datasets των GP01–GP10. Δεν περιλαμβάνει solution notebooks ή τα δεδομένα του Core Capstone.

## Τοπική εργασία

1. Αποσυμπίεσε το ZIP διατηρώντας ολόκληρη τη δομή φακέλων.
2. Άνοιξε τα notebooks από downloads/python/notebooks/starter/.
3. Τα datasets βρίσκονται στις αντίστοιχες διαδρομές downloads/python/data/gpXX/.
4. Εκτέλεσε πρώτα το κελί προετοιμασίας δεδομένων όπου υπάρχει. Τα notebooks μπορούν να κατεβάσουν τα δεδομένα από το public GeoSkills repository όταν δεν υπάρχει έγκυρο τοπικό cache.
5. Μην τροποποιείς τα αρχικά datasets· αποθήκευε τα δικά σου exports σε ξεχωριστό φάκελο.

## Colab

Για εργασία στο Google Colab χρησιμοποίησε τους συνδέσμους των αντίστοιχων σελίδων GP00–GP10. Οι σύνδεσμοι ανοίγουν τα starter notebooks από το pkazser/geoskills.

## Άδειες

Διάβασε το DATA_PROVENANCE.md. Η CC BY 4.0 αφορά μόνο τα συγκεκριμένα datasets GP01–GP10 και όχι αυτομάτως τα notebooks, το εκπαιδευτικό περιεχόμενο ή τα δεδομένα του Core Capstone.
